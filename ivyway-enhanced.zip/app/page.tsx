import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, Users, BookOpen, Award, Phone, Mail, MapPin, Star, Sparkles, Zap } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-purple-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-emerald-50 via-white to-purple-100 py-20 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-emerald-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-purple-400/20 to-emerald-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="h-6 w-6 text-emerald-600 animate-pulse" />
                <span className="text-emerald-600 font-semibold">Premium Education Consulting</span>
              </div>
              <h1 className="text-5xl font-bold text-slate-900 mb-6 leading-tight">
                Unlock Your Future: Get Into Your Dream Private School with
                <span className="bg-gradient-to-r from-emerald-600 to-purple-600 bg-clip-text text-transparent">
                  {" "}
                  IvyWay
                </span>
              </h1>
              <p className="text-xl text-slate-600 mb-8 leading-relaxed">
                IvyWay is the leading private school consulting company, helping students get into their top private
                schools at significantly higher rates than the average. Let our experts guide you to success.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/schedule">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-lg px-8 py-3 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 group"
                  >
                    <Calendar className="mr-2 h-5 w-5 group-hover:animate-bounce" />
                    Schedule Consultation
                  </Button>
                </Link>
                <Link href="/services">
                  <Button
                    variant="outline"
                    size="lg"
                    className="text-lg px-8 py-3 border-2 border-purple-500 text-purple-600 hover:bg-gradient-to-r hover:from-purple-50 hover:to-emerald-50 bg-transparent transition-all duration-300 hover:scale-105 hover:shadow-lg"
                  >
                    <Zap className="mr-2 h-5 w-5" />
                    View Our Services
                  </Button>
                </Link>
              </div>
            </div>

            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-emerald-100 hover:shadow-xl transition-all duration-300 hover:scale-105 hover:rotate-1">
                    <img
                      src="/private-school-crest-logo.png"
                      alt="School Logo"
                      className="w-full h-20 object-contain"
                    />
                  </div>
                  <div className="bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-purple-100 hover:shadow-xl transition-all duration-300 hover:scale-105 hover:-rotate-1">
                    <img src="/placeholder-6x7gj.png" alt="School Logo" className="w-full h-20 object-contain" />
                  </div>
                </div>
                <div className="space-y-4 mt-8">
                  <div className="bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-emerald-100 hover:shadow-xl transition-all duration-300 hover:scale-105 hover:-rotate-1">
                    <img
                      src="/lawrenceville-school-logo.png"
                      alt="Lawrenceville School"
                      className="w-full h-20 object-contain"
                    />
                  </div>
                  <div className="bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-purple-100 hover:shadow-xl transition-all duration-300 hover:scale-105 hover:rotate-1">
                    <img src="/placeholder-3opk4.png" alt="School Logo" className="w-full h-20 object-contain" />
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-emerald-600 to-purple-600 text-white p-3 rounded-full shadow-lg animate-bounce">
                <Award className="h-6 w-6" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gradient-to-br from-white to-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Star className="h-6 w-6 text-emerald-600 animate-pulse" />
              <span className="text-emerald-600 font-semibold">Premium Services</span>
              <Star className="h-6 w-6 text-purple-600 animate-pulse" />
            </div>
            <h2 className="text-4xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent mb-4">
              Our Services
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Comprehensive support to help you succeed in your private school journey
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 bg-gradient-to-br from-emerald-50 to-emerald-100 hover:from-emerald-100 hover:to-emerald-200 hover:shadow-2xl transition-all duration-500 hover:scale-105 hover:-rotate-1 group">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl group-hover:scale-110 transition-all duration-300">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-slate-900 mb-4">Private School Consultation</h3>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  Ivy Way guides families through the private school selection process, offering personalized planning,
                  application support for creating compelling statements, SSAT and ISEE test preparation, interview
                  preparation, and expert insights to help students stand out.
                </p>
                <Link href="/services/consultation">
                  <Button
                    variant="outline"
                    className="border-2 border-emerald-600 text-emerald-700 hover:bg-emerald-600 hover:text-white bg-transparent transition-all duration-300 hover:scale-105 shadow-md hover:shadow-lg"
                  >
                    More Info
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-0 bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 hover:shadow-2xl transition-all duration-500 hover:scale-105 group">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-purple-500 to-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl group-hover:scale-110 transition-all duration-300">
                  <Calendar className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-slate-900 mb-4">Summer Program Consulting</h3>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  At IvyWay, we specialize in guiding students to secure spots in the world's most competitive summer
                  programs. Whether you're aiming for academic enrichment, STEM exploration, or arts immersion, our
                  tailored support ensures you stand out in the application process.
                </p>
                <Link href="/services/summer">
                  <Button
                    variant="outline"
                    className="border-2 border-purple-600 text-purple-700 hover:bg-purple-600 hover:text-white bg-transparent transition-all duration-300 hover:scale-105 shadow-md hover:shadow-lg"
                  >
                    More Info
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-0 bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 hover:shadow-2xl transition-all duration-500 hover:scale-105 hover:rotate-1 group">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:shadow-xl group-hover:scale-110 transition-all duration-300">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-slate-900 mb-4">Enrichment Classes</h3>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  Ivy Way offers classes to strengthen academic foundations and explore new interests through subject
                  tutoring, skill development programs, specialized workshops like creative writing and STEM, flexible
                  scheduling, and an engaging, interactive learning environment.
                </p>
                <Link href="/services/classes">
                  <Button
                    variant="outline"
                    className="border-2 border-blue-600 text-blue-700 hover:bg-blue-600 hover:text-white bg-transparent transition-all duration-300 hover:scale-105 shadow-md hover:shadow-lg"
                  >
                    More Info
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-emerald-600 via-emerald-700 to-purple-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/90 to-purple-600/90"></div>
        <div className="absolute inset-0">
          <div className="absolute top-0 left-1/4 w-32 h-32 bg-white/10 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute bottom-0 right-1/4 w-24 h-24 bg-white/10 rounded-full blur-xl animate-pulse delay-1000"></div>
        </div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Schedule Your Classes?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Use our new interactive scheduling system to book consultations and enrichment classes at your convenience.
          </p>
          <Link href="/schedule">
            <Button
              size="lg"
              className="bg-white text-emerald-700 hover:bg-emerald-50 text-lg px-8 py-3 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-110 group"
            >
              <Calendar className="mr-2 h-5 w-5 group-hover:animate-spin" />
              Open Class Scheduler
            </Button>
          </Link>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-slate-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="h-6 w-6 text-purple-600 animate-pulse" />
                <span className="text-purple-600 font-semibold">Our Story</span>
              </div>
              <h2 className="text-4xl font-bold bg-gradient-to-r from-slate-900 to-purple-700 bg-clip-text text-transparent mb-6">
                About IvyWay
              </h2>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                Ivy Way is an educational initiative designed to empower K-8 students and their families, guiding them
                toward academic success. Originating as Project Engage, Ivy Way has grown into a profit-based business
                offering services such as:
              </p>
              <ul className="space-y-3 text-slate-600 mb-8">
                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-full p-1 mr-3 mt-1 shadow-md">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                  <span>
                    <strong className="text-emerald-700">Private School Consultation:</strong> Personalized support for
                    students aiming to secure admissions into competitive private schools.
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-full p-1 mr-3 mt-1 shadow-md">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                  <span>
                    <strong className="text-purple-700">SSAT/ISEE Test Preparation:</strong> Tailored test prep programs
                    to help students excel in standardized entrance exams.
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-full p-1 mr-3 mt-1 shadow-md">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                  <span>
                    <strong className="text-blue-700">Enrichment Classes:</strong> A variety of courses aimed at
                    enhancing academic performance, catering to specific subjects and skill-building.
                  </span>
                </li>
              </ul>
              <Link href="/about">
                <Button className="bg-gradient-to-r from-emerald-600 to-purple-600 hover:from-emerald-700 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                  Read More About Us
                </Button>
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img
                src="/placeholder-nrhoz.png"
                alt="School Campus"
                className="rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              />
              <img
                src="/classroom-study-session.png"
                alt="Students Learning"
                className="rounded-xl shadow-lg mt-8 hover:shadow-xl transition-all duration-300 hover:scale-105"
              />
              <img
                src="/private-school-graduation.png"
                alt="Graduation"
                className="rounded-xl shadow-lg -mt-8 hover:shadow-xl transition-all duration-300 hover:scale-105"
              />
              <img
                src="/academic-achievement-awards.png"
                alt="Achievement"
                className="rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              />
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-gradient-to-br from-slate-900 via-slate-800 to-purple-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-purple-400 bg-clip-text text-transparent mb-4">
                IvyWay
              </div>
              <p className="text-slate-300 mb-4">Your Guide to the Ivy World of Private Schools</p>
              <div className="flex items-center space-x-2 p-3 bg-white/10 rounded-lg backdrop-blur-sm">
                <Phone className="h-5 w-5 text-emerald-400" />
                <span className="text-slate-300">(609) 577-6565</span>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-emerald-400">Services</h3>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link
                    href="/services/consultation"
                    className="hover:text-emerald-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    Private School Consultation
                  </Link>
                </li>
                <li>
                  <Link
                    href="/services/summer"
                    className="hover:text-purple-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    Summer Program Consulting
                  </Link>
                </li>
                <li>
                  <Link
                    href="/services/classes"
                    className="hover:text-emerald-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    Enrichment Classes
                  </Link>
                </li>
                <li>
                  <Link
                    href="/services/test-prep"
                    className="hover:text-purple-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    Test Preparation
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-purple-400">Quick Links</h3>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link
                    href="/schedule"
                    className="hover:text-emerald-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    Schedule Classes
                  </Link>
                </li>
                <li>
                  <Link
                    href="/instructors"
                    className="hover:text-purple-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    Our Instructors
                  </Link>
                </li>
                <li>
                  <Link
                    href="/about"
                    className="hover:text-emerald-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    href="/contact"
                    className="hover:text-purple-400 transition-colors duration-300 hover:translate-x-1 inline-block"
                  >
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-emerald-400">Contact Info</h3>
              <div className="space-y-3 text-slate-300">
                <div className="flex items-center p-2 bg-white/5 rounded-lg">
                  <Mail className="h-4 w-4 mr-2 text-emerald-400" />
                  <span>info.ivyway@gmail.com</span>
                </div>
                <div className="flex items-center p-2 bg-white/5 rounded-lg">
                  <MapPin className="h-4 w-4 mr-2 text-purple-400" />
                  <span>New Jersey, USA</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-400">
            <p>
              &copy; 2024 IvyWay Enhanced. All rights reserved. Built with modern design and scheduling capabilities.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
