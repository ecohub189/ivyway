import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Award, BookOpen, Users, Calendar, Mail } from "lucide-react"
import Link from "next/link"

const instructors = [
  {
    id: "sarah-chen",
    name: "Dr. Sarah Chen",
    title: "Director of Academic Programs",
    image: "/instructor-sarah-chen.png",
    specialties: ["Private School Consulting", "Test Preparation", "Academic Planning"],
    education: ["Ph.D. in Education, Harvard University", "M.A. in Psychology, Stanford University"],
    experience: "15+ years",
    bio: "Dr. Chen has guided over 500 students through the private school application process with a 95% acceptance rate to top-choice schools. She specializes in creating personalized academic strategies and has extensive experience with SSAT/ISEE preparation.",
    achievements: [
      "Former Admissions Officer at Phillips Exeter Academy",
      "Published researcher in educational psychology",
      "Certified Educational Planner (CEP)",
    ],
    availability: ["Monday-Friday: 9:00 AM - 6:00 PM", "Saturday: 10:00 AM - 4:00 PM"],
  },
  {
    id: "michael-rodriguez",
    name: "Prof. Michael Rodriguez",
    title: "Senior Mathematics & Science Instructor",
    image: "/instructor-michael-rodriguez.png",
    specialties: ["Advanced Mathematics", "Physics", "STEM Programs", "Test Preparation"],
    education: ["M.S. in Mathematics, MIT", "B.S. in Physics, Caltech"],
    experience: "12+ years",
    bio: "Professor Rodriguez brings exceptional expertise in advanced mathematics and science education. He has helped hundreds of students excel in competitive academic environments and secure admission to top STEM programs.",
    achievements: [
      "Former faculty at prestigious boarding schools",
      "National Merit Scholar Program mentor",
      "Published mathematics curriculum developer",
    ],
    availability: ["Tuesday-Saturday: 10:00 AM - 7:00 PM", "Sunday: 1:00 PM - 5:00 PM"],
  },
  {
    id: "jennifer-park",
    name: "Ms. Jennifer Park",
    title: "Language Arts & Writing Specialist",
    image: "/instructor-jennifer-park.png",
    specialties: ["Creative Writing", "Essay Coaching", "Reading Comprehension", "Public Speaking"],
    education: ["M.F.A. in Creative Writing, Columbia University", "B.A. in English Literature, Yale University"],
    experience: "10+ years",
    bio: "Ms. Park is a published author and experienced educator who specializes in developing students' writing and communication skills. Her students consistently produce compelling essays that stand out in competitive applications.",
    achievements: [
      "Published novelist and poet",
      "Winner of National Teaching Excellence Award",
      "Former editor at major publishing house",
    ],
    availability: ["Monday-Thursday: 11:00 AM - 7:00 PM", "Saturday: 9:00 AM - 3:00 PM"],
  },
  {
    id: "david-kim",
    name: "Dr. David Kim",
    title: "Summer Program & College Counselor",
    image: "/instructor-david-kim.png",
    specialties: ["Summer Program Consulting", "College Preparation", "Leadership Development"],
    education: ["Ed.D. in Higher Education, University of Pennsylvania", "M.A. in Counseling, Northwestern University"],
    experience: "18+ years",
    bio: "Dr. Kim has extensive experience in competitive program placement and college counseling. He has successfully guided students into prestigious summer programs at Harvard, Stanford, MIT, and other top institutions.",
    achievements: [
      "Former Director of Summer Programs at elite prep school",
      "Certified College Counselor (CCC)",
      "Expert in competitive program admissions",
    ],
    availability: ["Monday-Friday: 8:00 AM - 5:00 PM", "Evening consultations by appointment"],
  },
]

export default function InstructorsPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Meet Our Expert Instructors</h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
              Learn from experienced educators and consultants who are passionate about helping students achieve their
              academic goals
            </p>
          </div>
        </div>
      </div>

      {/* Instructor Profiles */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16">
            {instructors.map((instructor, index) => (
              <div
                key={instructor.id}
                className={`grid lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? "lg:grid-flow-col-dense" : ""}`}
              >
                {/* Image */}
                <div className={`${index % 2 === 1 ? "lg:col-start-2" : ""}`}>
                  <div className="relative">
                    <img
                      src={instructor.image || "/placeholder.svg"}
                      alt={instructor.name}
                      className="w-full h-96 object-cover rounded-lg shadow-lg"
                    />
                    <div className="absolute -bottom-4 -right-4 bg-emerald-700 text-white p-3 rounded-full">
                      <GraduationCap className="h-6 w-6" />
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className={`${index % 2 === 1 ? "lg:col-start-1" : ""}`}>
                  <div className="mb-4">
                    <h2 className="text-3xl font-bold text-slate-900 mb-2">{instructor.name}</h2>
                    <p className="text-xl text-emerald-700 font-medium mb-4">{instructor.title}</p>
                    <div className="flex items-center text-slate-600 mb-4">
                      <Award className="h-4 w-4 mr-2" />
                      <span>{instructor.experience} of experience</span>
                    </div>
                  </div>

                  <p className="text-slate-600 mb-6 leading-relaxed">{instructor.bio}</p>

                  {/* Specialties */}
                  <div className="mb-6">
                    <h3 className="font-semibold text-slate-900 mb-3">Specialties</h3>
                    <div className="flex flex-wrap gap-2">
                      {instructor.specialties.map((specialty) => (
                        <Badge key={specialty} className="bg-emerald-100 text-emerald-700">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Education */}
                  <div className="mb-6">
                    <h3 className="font-semibold text-slate-900 mb-3 flex items-center">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Education
                    </h3>
                    <ul className="space-y-1">
                      {instructor.education.map((degree, idx) => (
                        <li key={idx} className="text-slate-600">
                          • {degree}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Key Achievements */}
                  <div className="mb-6">
                    <h3 className="font-semibold text-slate-900 mb-3">Key Achievements</h3>
                    <ul className="space-y-1">
                      {instructor.achievements.map((achievement, idx) => (
                        <li key={idx} className="text-slate-600">
                          • {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Availability */}
                  <div className="mb-6">
                    <h3 className="font-semibold text-slate-900 mb-3 flex items-center">
                      <Calendar className="h-4 w-4 mr-2" />
                      Availability
                    </h3>
                    <ul className="space-y-1">
                      {instructor.availability.map((time, idx) => (
                        <li key={idx} className="text-slate-600">
                          • {time}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link href={`/schedule?instructor=${instructor.id}`}>
                      <Button className="bg-emerald-700 hover:bg-emerald-800">
                        <Calendar className="mr-2 h-4 w-4" />
                        Schedule Session
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      className="border-emerald-700 text-emerald-700 hover:bg-emerald-50 bg-transparent"
                    >
                      <Mail className="mr-2 h-4 w-4" />
                      Contact Instructor
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Stats */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Our Team's Impact</h2>

          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-emerald-700 mb-2">1000+</div>
              <div className="text-slate-600">Students Taught</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-emerald-700 mb-2">95%</div>
              <div className="text-slate-600">Success Rate</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-emerald-700 mb-2">50+</div>
              <div className="text-slate-600">Years Combined Experience</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-emerald-700 mb-2">25+</div>
              <div className="text-slate-600">Top Schools Represented</div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Our Instructors */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Why Choose Our Instructors?</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <GraduationCap className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Elite Education</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  All our instructors hold advanced degrees from top universities and bring real-world experience from
                  prestigious institutions.
                </p>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <Users className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Personalized Approach</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Each instructor tailors their teaching methods to individual learning styles and academic goals for
                  maximum effectiveness.
                </p>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <Award className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Proven Results</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Our instructors have consistently helped students achieve their academic goals and gain admission to
                  their dream schools.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-emerald-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Work with Our Expert Team?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Schedule a consultation or class with one of our experienced instructors today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/schedule">
              <Button size="lg" className="bg-white text-emerald-700 hover:bg-emerald-50">
                <Calendar className="mr-2 h-5 w-5" />
                Schedule Now
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-emerald-600 bg-transparent"
              >
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
