import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Target, TrendingUp, CheckCircle, Calendar, Users } from "lucide-react"

export default function TestPrepPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="bg-emerald-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <GraduationCap className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Test Preparation</h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
              Comprehensive SSAT and ISEE preparation programs designed to maximize scores and build confidence
            </p>
          </div>
        </div>
      </div>

      {/* Test Options */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Test Preparation Programs</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* SSAT Prep */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl text-emerald-700">SSAT Preparation</CardTitle>
                  <Badge className="bg-emerald-100 text-emerald-700">Most Popular</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6">
                  Comprehensive preparation for the Secondary School Admission Test, covering all sections with proven
                  strategies and practice materials.
                </p>

                <div className="space-y-4 mb-6">
                  <h4 className="font-semibold text-slate-900">What's Covered:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Verbal Reasoning & Vocabulary
                    </li>
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Quantitative Math Sections
                    </li>
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Reading Comprehension
                    </li>
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Writing Sample (Optional)
                    </li>
                  </ul>
                </div>

                <div className="bg-slate-50 p-4 rounded-lg mb-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="font-semibold text-slate-900">Duration</div>
                      <div className="text-sm text-slate-600">8-12 weeks</div>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900">Sessions</div>
                      <div className="text-sm text-slate-600">2 hours/week</div>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900">Class Size</div>
                      <div className="text-sm text-slate-600">Max 6 students</div>
                    </div>
                  </div>
                </div>

                <Button className="w-full bg-emerald-700 hover:bg-emerald-800">Enroll in SSAT Prep</Button>
              </CardContent>
            </Card>

            {/* ISEE Prep */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-2xl text-emerald-700">ISEE Preparation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6">
                  Targeted preparation for the Independent School Entrance Examination, with level-specific content and
                  adaptive learning strategies.
                </p>

                <div className="space-y-4 mb-6">
                  <h4 className="font-semibold text-slate-900">What's Covered:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Verbal Reasoning & Synonyms
                    </li>
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Quantitative Reasoning
                    </li>
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Reading Comprehension
                    </li>
                    <li className="flex items-center text-slate-600">
                      <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                      Mathematics Achievement
                    </li>
                  </ul>
                </div>

                <div className="bg-slate-50 p-4 rounded-lg mb-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="font-semibold text-slate-900">Duration</div>
                      <div className="text-sm text-slate-600">6-10 weeks</div>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900">Sessions</div>
                      <div className="text-sm text-slate-600">2 hours/week</div>
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900">Class Size</div>
                      <div className="text-sm text-slate-600">Max 6 students</div>
                    </div>
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full border-emerald-700 text-emerald-700 hover:bg-emerald-50 bg-transparent"
                >
                  Enroll in ISEE Prep
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Program Features */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Our Approach</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <Target className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Diagnostic Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Comprehensive initial assessment to identify strengths and areas for improvement, creating a
                  personalized study plan.
                </p>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Progress Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Regular practice tests and progress monitoring to ensure steady improvement and identify areas needing
                  additional focus.
                </p>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <Users className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Expert Instruction</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Experienced instructors with proven track records in test preparation and deep knowledge of exam
                  formats.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Study Materials */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Comprehensive Study Materials</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Official Practice Tests</h3>
                <p className="text-slate-600 text-sm">
                  Access to official SSAT and ISEE practice tests with detailed answer explanations
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Vocabulary Building</h3>
                <p className="text-slate-600 text-sm">
                  Comprehensive vocabulary lists and memory techniques for verbal sections
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Math Review Materials</h3>
                <p className="text-slate-600 text-sm">
                  Complete review of mathematical concepts with practice problems and shortcuts
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Reading Strategies</h3>
                <p className="text-slate-600 text-sm">
                  Proven techniques for improving reading speed and comprehension accuracy
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Test-Taking Strategies</h3>
                <p className="text-slate-600 text-sm">
                  Time management techniques and strategies for handling difficult questions
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Homework & Practice</h3>
                <p className="text-slate-600 text-sm">
                  Weekly assignments and additional practice materials for reinforcement
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Success Metrics */}
      <section className="py-16 bg-emerald-700">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-white mb-12">Proven Results</h2>

          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-white mb-2">250+</div>
              <div className="text-emerald-100">Average Score Increase</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">92%</div>
              <div className="text-emerald-100">Score Improvement Rate</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">500+</div>
              <div className="text-emerald-100">Students Prepared</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">85%</div>
              <div className="text-emerald-100">Top School Acceptance</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Ready to Boost Your Test Scores?</h2>
          <p className="text-xl text-slate-600 mb-8">
            Join our proven test preparation program and achieve the scores you need for your dream school.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-emerald-700 hover:bg-emerald-800">
              <Calendar className="mr-2 h-5 w-5" />
              Schedule Assessment
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-emerald-700 text-emerald-700 hover:bg-emerald-50 bg-transparent"
            >
              View Class Schedule
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
