import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Globe, Award, CheckCircle, Users } from "lucide-react"

export default function SummerProgramPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="bg-emerald-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Summer Program Consulting</h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
              Secure spots in the world's most competitive summer programs with expert guidance and strategic support
            </p>
          </div>
        </div>
      </div>

      {/* Overview */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Stand Out in Competitive Summer Programs</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              At IvyWay, we specialize in guiding students to secure spots in the world's most competitive summer
              programs. Whether you're aiming for academic enrichment, STEM exploration, or arts immersion, our tailored
              support ensures you stand out in the application process.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <Globe className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Global Programs</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Access to prestigious programs at top universities and institutions worldwide
                </p>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <Award className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Competitive Edge</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Strategic guidance to make your application stand out from thousands</p>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 text-center">
              <CardHeader>
                <Users className="h-12 w-12 text-emerald-700 mx-auto mb-2" />
                <CardTitle className="text-emerald-700">Expert Support</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Personalized guidance from consultants with proven track records</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Program Categories */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Summer Program Categories</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-emerald-700">Academic Enrichment</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li>• Harvard Summer School</li>
                  <li>• Stanford Pre-Collegiate</li>
                  <li>• Yale Young Global Scholars</li>
                  <li>• MIT Launch</li>
                  <li>• Princeton Summer Journalism</li>
                </ul>
                <Badge className="mt-3 bg-emerald-100 text-emerald-700">15+ Programs</Badge>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-emerald-700">STEM & Technology</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li>• NASA USRP</li>
                  <li>• Research Science Institute</li>
                  <li>• Carnegie Mellon SAMS</li>
                  <li>• Cooper Union Summer STEM</li>
                  <li>• Johns Hopkins CTY</li>
                </ul>
                <Badge className="mt-3 bg-emerald-100 text-emerald-700">20+ Programs</Badge>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-emerald-700">Arts & Humanities</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li>• Interlochen Arts Camp</li>
                  <li>• RISD Pre-College</li>
                  <li>• Juilliard Summer Programs</li>
                  <li>• Iowa Young Writers' Studio</li>
                  <li>• Parsons Summer Intensive</li>
                </ul>
                <Badge className="mt-3 bg-emerald-100 text-emerald-700">12+ Programs</Badge>
              </CardContent>
            </Card>

            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-emerald-700">Leadership & Service</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li>• TASP (Telluride)</li>
                  <li>• NSLI-Y Language Programs</li>
                  <li>• Global Citizen Year</li>
                  <li>• Experiment in International Living</li>
                  <li>• World Affairs Seminar</li>
                </ul>
                <Badge className="mt-3 bg-emerald-100 text-emerald-700">10+ Programs</Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Our Consulting Process</h2>

          <div className="grid md:grid-cols-5 gap-6">
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">1</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Profile Assessment</h3>
              <p className="text-slate-600 text-sm">Evaluate interests, strengths, and academic goals</p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">2</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Program Matching</h3>
              <p className="text-slate-600 text-sm">Identify programs that align with student profile</p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">3</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Application Strategy</h3>
              <p className="text-slate-600 text-sm">Develop compelling application narratives</p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">4</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Essay Support</h3>
              <p className="text-slate-600 text-sm">Craft standout essays and personal statements</p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">5</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Final Review</h3>
              <p className="text-slate-600 text-sm">Polish applications before submission</p>
            </div>
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Comprehensive Support Package</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Program Research & Selection</h3>
                <p className="text-slate-600 text-sm">
                  Comprehensive research of 50+ programs to find the perfect matches
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Application Timeline</h3>
                <p className="text-slate-600 text-sm">Detailed timeline with all deadlines and requirements</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Essay Writing Guidance</h3>
                <p className="text-slate-600 text-sm">Multiple rounds of feedback on essays and personal statements</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Recommendation Strategy</h3>
                <p className="text-slate-600 text-sm">Guidance on securing strong letters of recommendation</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Interview Preparation</h3>
                <p className="text-slate-600 text-sm">Mock interviews for programs that require them</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Scholarship Guidance</h3>
                <p className="text-slate-600 text-sm">Help identifying and applying for financial aid opportunities</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Success Stats */}
      <section className="py-16 bg-emerald-700">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-white mb-12">Our Track Record</h2>

          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-white mb-2">95%</div>
              <div className="text-emerald-100">Acceptance Rate</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">200+</div>
              <div className="text-emerald-100">Students Placed</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">50+</div>
              <div className="text-emerald-100">Partner Programs</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">$2M+</div>
              <div className="text-emerald-100">Scholarships Secured</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Start Your Summer Program Journey</h2>
          <p className="text-xl text-slate-600 mb-8">
            Schedule a consultation to discuss your summer program goals and create a winning application strategy.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-emerald-700 hover:bg-emerald-800">
              <Calendar className="mr-2 h-5 w-5" />
              Schedule Consultation
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-emerald-700 text-emerald-700 hover:bg-emerald-50 bg-transparent"
            >
              Download Program Guide
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
