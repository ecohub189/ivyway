import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Target, Award, CheckCircle, Calendar } from "lucide-react"

export default function ConsultationPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="bg-emerald-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Private School Consultation</h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
              Expert guidance through every step of the private school application process
            </p>
          </div>
        </div>
      </div>

      {/* Overview */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Comprehensive Private School Support</h2>
            <p className="text-lg text-slate-600 leading-relaxed">
              IvyWay guides families through the complex private school selection process with personalized planning,
              application support, and expert insights to help students stand out from the competition.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-emerald-100">
              <CardHeader>
                <CardTitle className="flex items-center text-emerald-700">
                  <Target className="h-5 w-5 mr-2" />
                  School Matching
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  We analyze your child's academic profile, interests, and goals to identify the best-fit private
                  schools that align with your family's values and expectations.
                </p>
              </CardContent>
            </Card>

            <Card className="border-emerald-100">
              <CardHeader>
                <CardTitle className="flex items-center text-emerald-700">
                  <Award className="h-5 w-5 mr-2" />
                  Application Excellence
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Our experts help craft compelling personal statements, essays, and applications that showcase your
                  child's unique strengths and potential.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Our Consultation Process</h2>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">1</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Initial Assessment</h3>
              <p className="text-slate-600 text-sm">
                Comprehensive evaluation of academic strengths, interests, and goals
              </p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">2</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">School Research</h3>
              <p className="text-slate-600 text-sm">
                Identify and research schools that match your child's profile and family preferences
              </p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">3</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Application Support</h3>
              <p className="text-slate-600 text-sm">Guidance on essays, interviews, and all application components</p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-700">4</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Decision Support</h3>
              <p className="text-slate-600 text-sm">
                Help evaluate offers and make the final school selection decision
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">What's Included</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Personalized School List</h3>
                <p className="text-slate-600 text-sm">Curated list of 8-12 schools that match your criteria</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Essay Writing Support</h3>
                <p className="text-slate-600 text-sm">Guidance on personal statements and supplemental essays</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Interview Preparation</h3>
                <p className="text-slate-600 text-sm">Mock interviews and coaching for admission interviews</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Timeline Management</h3>
                <p className="text-slate-600 text-sm">Detailed timeline with deadlines and milestones</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Parent Guidance</h3>
                <p className="text-slate-600 text-sm">Support for parent statements and family involvement</p>
              </div>
            </div>

            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900 mb-1">Ongoing Support</h3>
                <p className="text-slate-600 text-sm">Regular check-ins and support throughout the process</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-emerald-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Start Your Journey?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Schedule a consultation to discuss your private school goals and create a personalized strategy.
          </p>
          <Button size="lg" className="bg-white text-emerald-700 hover:bg-emerald-50">
            <Calendar className="mr-2 h-5 w-5" />
            Schedule Consultation
          </Button>
        </div>
      </section>
    </div>
  )
}
