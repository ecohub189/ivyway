import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Users, Clock, Star, Calendar } from "lucide-react"

export default function ClassesPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="bg-emerald-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <BookOpen className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Enrichment Classes</h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
              Interactive classes designed to strengthen academic foundations and explore new interests
            </p>
          </div>
        </div>
      </div>

      {/* Class Categories */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Available Classes</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Math & Science */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-emerald-700">Math & Science</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Advanced Mathematics</span>
                    <Badge variant="secondary">Grades 6-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Physics Fundamentals</span>
                    <Badge variant="secondary">Grades 7-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Chemistry Basics</span>
                    <Badge variant="secondary">Grades 6-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Biology Exploration</span>
                    <Badge variant="secondary">Grades 5-7</Badge>
                  </div>
                </div>
                <div className="mt-6 flex items-center text-sm text-slate-600">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>1.5 hours/week</span>
                  <Users className="h-4 w-4 ml-4 mr-1" />
                  <span>Max 8 students</span>
                </div>
              </CardContent>
            </Card>

            {/* Language Arts */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-emerald-700">Language Arts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Creative Writing</span>
                    <Badge variant="secondary">Grades 4-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Reading Comprehension</span>
                    <Badge variant="secondary">Grades 3-6</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Essay Writing</span>
                    <Badge variant="secondary">Grades 6-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Public Speaking</span>
                    <Badge variant="secondary">Grades 5-8</Badge>
                  </div>
                </div>
                <div className="mt-6 flex items-center text-sm text-slate-600">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>1 hour/week</span>
                  <Users className="h-4 w-4 ml-4 mr-1" />
                  <span>Max 6 students</span>
                </div>
              </CardContent>
            </Card>

            {/* STEM & Technology */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-emerald-700">STEM & Technology</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Coding Fundamentals</span>
                    <Badge variant="secondary">Grades 4-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Robotics</span>
                    <Badge variant="secondary">Grades 5-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Engineering Design</span>
                    <Badge variant="secondary">Grades 6-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">3D Modeling</span>
                    <Badge variant="secondary">Grades 7-8</Badge>
                  </div>
                </div>
                <div className="mt-6 flex items-center text-sm text-slate-600">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>2 hours/week</span>
                  <Users className="h-4 w-4 ml-4 mr-1" />
                  <span>Max 10 students</span>
                </div>
              </CardContent>
            </Card>

            {/* Arts & Creativity */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-emerald-700">Arts & Creativity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Digital Art</span>
                    <Badge variant="secondary">Grades 5-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Music Theory</span>
                    <Badge variant="secondary">Grades 4-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Drama & Theater</span>
                    <Badge variant="secondary">Grades 3-7</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Photography</span>
                    <Badge variant="secondary">Grades 6-8</Badge>
                  </div>
                </div>
                <div className="mt-6 flex items-center text-sm text-slate-600">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>1.5 hours/week</span>
                  <Users className="h-4 w-4 ml-4 mr-1" />
                  <span>Max 8 students</span>
                </div>
              </CardContent>
            </Card>

            {/* Test Prep */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-emerald-700">Test Preparation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">SSAT Prep</span>
                    <Badge variant="secondary">Grades 6-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">ISEE Prep</span>
                    <Badge variant="secondary">Grades 5-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Study Skills</span>
                    <Badge variant="secondary">Grades 4-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Time Management</span>
                    <Badge variant="secondary">Grades 5-8</Badge>
                  </div>
                </div>
                <div className="mt-6 flex items-center text-sm text-slate-600">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>2 hours/week</span>
                  <Users className="h-4 w-4 ml-4 mr-1" />
                  <span>Max 6 students</span>
                </div>
              </CardContent>
            </Card>

            {/* Academic Support */}
            <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-emerald-700">Academic Support</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Homework Help</span>
                    <Badge variant="secondary">Grades 3-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Organization Skills</span>
                    <Badge variant="secondary">Grades 4-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Note-Taking</span>
                    <Badge variant="secondary">Grades 5-8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Research Skills</span>
                    <Badge variant="secondary">Grades 6-8</Badge>
                  </div>
                </div>
                <div className="mt-6 flex items-center text-sm text-slate-600">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>1 hour/week</span>
                  <Users className="h-4 w-4 ml-4 mr-1" />
                  <span>Max 4 students</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Why Choose Our Classes?</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-emerald-700" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Expert Instructors</h3>
              <p className="text-slate-600">
                All our instructors are experienced educators with advanced degrees and specialized training in their
                subjects.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-emerald-700" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Small Class Sizes</h3>
              <p className="text-slate-600">
                We maintain small class sizes to ensure personalized attention and meaningful interaction with
                instructors.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-emerald-700" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Flexible Scheduling</h3>
              <p className="text-slate-600">
                Choose from multiple time slots and session formats to fit your family's busy schedule.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-emerald-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Enroll?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Browse our class schedule and register for the programs that interest you most.
          </p>
          <Button size="lg" className="bg-white text-emerald-700 hover:bg-emerald-50">
            <Calendar className="mr-2 h-5 w-5" />
            View Class Schedule
          </Button>
        </div>
      </section>
    </div>
  )
}
