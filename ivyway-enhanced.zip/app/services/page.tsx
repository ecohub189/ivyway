import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Calendar, BookOpen, GraduationCap, CheckCircle, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Our Services</h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
              Comprehensive educational consulting and enrichment programs designed to help students excel in their
              academic journey
            </p>
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Private School Consultation */}
            <Card className="border-emerald-100 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="pb-4">
                <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 group-hover:bg-emerald-200 transition-colors">
                  <Users className="h-8 w-8 text-emerald-700" />
                </div>
                <CardTitle className="text-2xl text-slate-900">Private School Consultation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  Expert guidance through the entire private school application process, from school selection to
                  interview preparation.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Personalized school matching
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Application essay support
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Interview preparation
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Timeline management
                  </li>
                </ul>
                <Link href="/services/consultation">
                  <Button className="w-full bg-emerald-700 hover:bg-emerald-800 group">
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Summer Program Consulting */}
            <Card className="border-emerald-100 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="pb-4">
                <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 group-hover:bg-emerald-200 transition-colors">
                  <Calendar className="h-8 w-8 text-emerald-700" />
                </div>
                <CardTitle className="text-2xl text-slate-900">Summer Program Consulting</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  Secure spots in competitive summer programs that enhance academic profiles and provide enriching
                  experiences.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Program research & matching
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Application strategy
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Essay writing support
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Scholarship guidance
                  </li>
                </ul>
                <Link href="/services/summer">
                  <Button className="w-full bg-emerald-700 hover:bg-emerald-800 group">
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Enrichment Classes */}
            <Card className="border-emerald-100 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="pb-4">
                <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 group-hover:bg-emerald-200 transition-colors">
                  <BookOpen className="h-8 w-8 text-emerald-700" />
                </div>
                <CardTitle className="text-2xl text-slate-900">Enrichment Classes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  Interactive classes designed to strengthen academic foundations and explore new interests in a
                  supportive environment.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Subject-specific tutoring
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Creative writing workshops
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    STEM exploration
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Flexible scheduling
                  </li>
                </ul>
                <Link href="/services/classes">
                  <Button className="w-full bg-emerald-700 hover:bg-emerald-800 group">
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Test Preparation */}
            <Card className="border-emerald-100 hover:shadow-xl transition-all duration-300 group">
              <CardHeader className="pb-4">
                <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 group-hover:bg-emerald-200 transition-colors">
                  <GraduationCap className="h-8 w-8 text-emerald-700" />
                </div>
                <CardTitle className="text-2xl text-slate-900">Test Preparation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  Comprehensive SSAT and ISEE test preparation programs designed to maximize scores and build
                  confidence.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Diagnostic assessments
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Personalized study plans
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Practice tests & analysis
                  </li>
                  <li className="flex items-center text-slate-600">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2" />
                    Test-taking strategies
                  </li>
                </ul>
                <Link href="/services/test-prep">
                  <Button className="w-full bg-emerald-700 hover:bg-emerald-800 group">
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-slate-600 mb-8">
            Schedule a consultation to discuss your educational goals and create a personalized plan for success.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-emerald-700 hover:bg-emerald-800">
              Schedule Consultation
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-emerald-700 text-emerald-700 hover:bg-emerald-50 bg-transparent"
            >
              View Class Schedule
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
