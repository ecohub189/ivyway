"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Phone, Mail, MapPin, Clock, MessageCircle, Calendar, CheckCircle } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    studentGrade: "",
    message: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    setIsSubmitted(true)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="max-w-md mx-auto text-center px-4">
          <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-10 w-10 text-emerald-700" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Message Sent!</h1>
          <p className="text-slate-600 mb-8">
            Thank you for contacting IvyWay. We'll get back to you within 24 hours to discuss how we can help with your
            educational goals.
          </p>
          <Button onClick={() => setIsSubmitted(false)} className="bg-emerald-700 hover:bg-emerald-800">
            Send Another Message
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Contact IvyWay</h1>
            <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
              Ready to start your educational journey? Get in touch with our expert team today.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Information */}
          <div className="lg:col-span-1">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Get in Touch</h2>
            <p className="text-slate-600 mb-8">
              We're here to answer your questions and help you take the next step in your educational journey. Reach out
              to us using any of the methods below.
            </p>

            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-emerald-100 rounded-full p-2 mr-4">
                  <Phone className="h-5 w-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Phone</h3>
                  <p className="text-slate-600">(609) 577-6565</p>
                  <p className="text-sm text-slate-500">Monday-Friday: 9:00 AM - 6:00 PM EST</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-emerald-100 rounded-full p-2 mr-4">
                  <Mail className="h-5 w-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Email</h3>
                  <p className="text-slate-600">info.ivyway@gmail.com</p>
                  <p className="text-sm text-slate-500">We respond within 24 hours</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-emerald-100 rounded-full p-2 mr-4">
                  <MapPin className="h-5 w-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Location</h3>
                  <p className="text-slate-600">New Jersey, USA</p>
                  <p className="text-sm text-slate-500">Serving families nationwide</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-emerald-100 rounded-full p-2 mr-4">
                  <Clock className="h-5 w-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Office Hours</h3>
                  <div className="text-slate-600 text-sm space-y-1">
                    <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                    <p>Saturday: 10:00 AM - 4:00 PM</p>
                    <p>Sunday: By appointment only</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="mt-8 space-y-3">
              <Button className="w-full bg-emerald-700 hover:bg-emerald-800">
                <Calendar className="mr-2 h-4 w-4" />
                Schedule Consultation
              </Button>
              <Button
                variant="outline"
                className="w-full border-emerald-700 text-emerald-700 hover:bg-emerald-50 bg-transparent"
              >
                <MessageCircle className="mr-2 h-4 w-4" />
                Live Chat Support
              </Button>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card className="border-emerald-100">
              <CardHeader>
                <CardTitle className="text-emerald-700">Send Us a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        required
                        value={formData.name}
                        onChange={(e) => handleInputChange("name", e.target.value)}
                        className="border-emerald-200 focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        className="border-emerald-200 focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        className="border-emerald-200 focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <Label htmlFor="studentGrade">Student's Current Grade</Label>
                      <Select onValueChange={(value) => handleInputChange("studentGrade", value)}>
                        <SelectTrigger className="border-emerald-200 focus:border-emerald-500">
                          <SelectValue placeholder="Select grade level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="k">Kindergarten</SelectItem>
                          <SelectItem value="1">1st Grade</SelectItem>
                          <SelectItem value="2">2nd Grade</SelectItem>
                          <SelectItem value="3">3rd Grade</SelectItem>
                          <SelectItem value="4">4th Grade</SelectItem>
                          <SelectItem value="5">5th Grade</SelectItem>
                          <SelectItem value="6">6th Grade</SelectItem>
                          <SelectItem value="7">7th Grade</SelectItem>
                          <SelectItem value="8">8th Grade</SelectItem>
                          <SelectItem value="9">9th Grade</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="subject">Subject *</Label>
                    <Select onValueChange={(value) => handleInputChange("subject", value)} required>
                      <SelectTrigger className="border-emerald-200 focus:border-emerald-500">
                        <SelectValue placeholder="What can we help you with?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="consultation">Private School Consultation</SelectItem>
                        <SelectItem value="enrichment">Enrichment Classes</SelectItem>
                        <SelectItem value="test-prep">Test Preparation</SelectItem>
                        <SelectItem value="summer-programs">Summer Program Consulting</SelectItem>
                        <SelectItem value="general">General Inquiry</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      required
                      placeholder="Tell us about your educational goals, questions, or how we can help..."
                      value={formData.message}
                      onChange={(e) => handleInputChange("message", e.target.value)}
                      className="border-emerald-200 focus:border-emerald-500 min-h-32"
                    />
                  </div>

                  <Button type="submit" size="lg" className="w-full bg-emerald-700 hover:bg-emerald-800">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Frequently Asked Questions</h2>

          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">How do I get started with IvyWay?</h3>
              <p className="text-slate-600">
                The best way to get started is to schedule a consultation where we can discuss your student's goals and
                create a personalized plan. You can schedule online or contact us directly.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">What ages do you work with?</h3>
              <p className="text-slate-600">
                We primarily work with K-8 students, though we also provide guidance for high school students in
                specific areas like summer program consulting and test preparation.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Do you offer virtual sessions?</h3>
              <p className="text-slate-600">
                Yes! We offer both in-person and virtual sessions to accommodate families nationwide. Our virtual
                platform provides the same high-quality instruction and personalized attention.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">What is your success rate?</h3>
              <p className="text-slate-600">
                We maintain a 95% success rate for private school admissions, with students consistently gaining
                admission to their top-choice schools. Our test prep students see an average score increase of 250+
                points.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
