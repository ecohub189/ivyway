"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Clock, ArrowLeft, ArrowRight, CreditCard } from "lucide-react"

type ServiceType = "consultation" | "enrichment" | "test-prep" | "summer-program"
type TimeSlot = {
  time: string
  available: boolean
  instructor?: string
}

const services = {
  consultation: {
    name: "Private School Consultation",
    duration: "60 minutes",
    price: "$150",
    priceAmount: 15000, // Added price in cents for Stripe
    description: "One-on-one consultation for private school planning",
  },
  enrichment: {
    name: "Enrichment Classes",
    duration: "90 minutes",
    price: "$75",
    priceAmount: 7500, // Added price in cents for Stripe
    description: "Subject-specific enrichment and tutoring",
  },
  "test-prep": {
    name: "Test Preparation",
    duration: "120 minutes",
    price: "$100",
    priceAmount: 10000, // Added price in cents for Stripe
    description: "SSAT/ISEE test preparation sessions",
  },
  "summer-program": {
    name: "Summer Program Consulting",
    duration: "45 minutes",
    price: "$125",
    priceAmount: 12500, // Added price in cents for Stripe
    description: "Guidance for competitive summer programs",
  },
}

const timeSlots: TimeSlot[] = [
  { time: "9:00 AM", available: true, instructor: "Dr. Sarah Chen" },
  { time: "10:30 AM", available: true, instructor: "Prof. Michael Rodriguez" },
  { time: "12:00 PM", available: false },
  { time: "1:30 PM", available: true, instructor: "Dr. Sarah Chen" },
  { time: "3:00 PM", available: true, instructor: "Ms. Jennifer Park" },
  { time: "4:30 PM", available: true, instructor: "Prof. Michael Rodriguez" },
  { time: "6:00 PM", available: true, instructor: "Dr. Sarah Chen" },
  { time: "7:30 PM", available: false },
]

export default function SchedulePage() {
  const [step, setStep] = useState(1)
  const [selectedService, setSelectedService] = useState<ServiceType | null>(null)
  const [selectedDate, setSelectedDate] = useState<string>("")
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [formData, setFormData] = useState({
    studentName: "",
    parentName: "",
    email: "",
    phone: "",
    grade: "",
    notes: "",
  })
  const [isProcessingPayment, setIsProcessingPayment] = useState(false) // Added payment processing state

  const handleServiceSelect = (service: ServiceType) => {
    setSelectedService(service)
    setStep(2)
  }

  const handleDateSelect = (date: string) => {
    setSelectedDate(date)
  }

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time)
    setStep(3)
  }

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setStep(4) // Go to payment step
  }

  const handlePayment = async () => {
    if (!selectedService) return

    setIsProcessingPayment(true)

    try {
      const response = await fetch("/api/create-payment-intent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: services[selectedService].priceAmount,
          service: services[selectedService].name,
          date: selectedDate,
          time: selectedTime,
          studentInfo: formData,
        }),
      })

      const { clientSecret } = await response.json()

      // Redirect to Stripe Checkout
      const stripe = await import("@stripe/stripe-js").then((mod) =>
        mod.loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!),
      )

      if (stripe) {
        await stripe.redirectToCheckout({ sessionId: clientSecret })
      }
    } catch (error) {
      console.error("Payment error:", error)
      setIsProcessingPayment(false)
    }
  }

  const generateDates = () => {
    const dates = []
    const today = new Date()
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      dates.push({
        date: date.toISOString().split("T")[0],
        display: date.toLocaleDateString("en-US", {
          weekday: "short",
          month: "short",
          day: "numeric",
        }),
      })
    }
    return dates
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-emerald-700 text-white py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Schedule Your Session</h1>
            <p className="text-xl text-emerald-100">Book consultations and classes with our expert instructors</p>
          </div>
        </div>
      </div>

      {/* Progress Indicator */}
      <div className="bg-slate-50 py-6">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center space-x-8">
            <div className={`flex items-center ${step >= 1 ? "text-emerald-700" : "text-slate-400"}`}>
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= 1 ? "bg-emerald-700 text-white" : "bg-slate-300 text-slate-600"
                }`}
              >
                1
              </div>
              <span className="ml-2 font-medium">Select Service</span>
            </div>
            <ArrowRight className="h-4 w-4 text-slate-400" />
            <div className={`flex items-center ${step >= 2 ? "text-emerald-700" : "text-slate-400"}`}>
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= 2 ? "bg-emerald-700 text-white" : "bg-slate-300 text-slate-600"
                }`}
              >
                2
              </div>
              <span className="ml-2 font-medium">Choose Time</span>
            </div>
            <ArrowRight className="h-4 w-4 text-slate-400" />
            <div className={`flex items-center ${step >= 3 ? "text-emerald-700" : "text-slate-400"}`}>
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= 3 ? "bg-emerald-700 text-white" : "bg-slate-300 text-slate-600"
                }`}
              >
                3
              </div>
              <span className="ml-2 font-medium">Your Details</span>
            </div>
            <ArrowRight className="h-4 w-4 text-slate-400" />
            <div className={`flex items-center ${step >= 4 ? "text-emerald-700" : "text-slate-400"}`}>
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= 4 ? "bg-emerald-700 text-white" : "bg-slate-300 text-slate-600"
                }`}
              >
                4
              </div>
              <span className="ml-2 font-medium">Payment</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Step 1: Service Selection */}
        {step === 1 && (
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Choose Your Service</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {Object.entries(services).map(([key, service]) => (
                <Card
                  key={key}
                  className="border-emerald-100 hover:shadow-lg transition-all cursor-pointer group"
                  onClick={() => handleServiceSelect(key as ServiceType)}
                >
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-emerald-700 group-hover:text-emerald-800">{service.name}</CardTitle>
                      <Badge className="bg-emerald-100 text-emerald-700">{service.price}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600 mb-4">{service.description}</p>
                    <div className="flex items-center text-sm text-slate-500">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{service.duration}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Date and Time Selection */}
        {step === 2 && selectedService && (
          <div>
            <div className="flex items-center mb-6">
              <Button variant="ghost" onClick={() => setStep(1)} className="text-emerald-700 hover:text-emerald-800">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Services
              </Button>
            </div>

            <h2 className="text-3xl font-bold text-slate-900 mb-2 text-center">Select Date & Time</h2>
            <div className="text-center mb-8">
              <Badge className="bg-emerald-100 text-emerald-700">
                {services[selectedService].name} - {services[selectedService].duration}
              </Badge>
            </div>

            {/* Date Selection */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold text-slate-900 mb-4">Choose a Date</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                {generateDates().map((dateObj) => (
                  <Button
                    key={dateObj.date}
                    variant={selectedDate === dateObj.date ? "default" : "outline"}
                    className={`p-4 h-auto flex-col ${
                      selectedDate === dateObj.date
                        ? "bg-emerald-700 hover:bg-emerald-800"
                        : "border-emerald-200 text-slate-700 hover:border-emerald-400"
                    }`}
                    onClick={() => handleDateSelect(dateObj.date)}
                  >
                    <div className="text-sm font-medium">{dateObj.display}</div>
                  </Button>
                ))}
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div>
                <h3 className="text-xl font-semibold text-slate-900 mb-4">Available Times</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {timeSlots.map((slot) => (
                    <Button
                      key={slot.time}
                      variant={selectedTime === slot.time ? "default" : "outline"}
                      disabled={!slot.available}
                      className={`p-4 h-auto flex-col ${
                        selectedTime === slot.time
                          ? "bg-emerald-700 hover:bg-emerald-800"
                          : slot.available
                            ? "border-emerald-200 text-slate-700 hover:border-emerald-400"
                            : "opacity-50 cursor-not-allowed"
                      }`}
                      onClick={() => slot.available && handleTimeSelect(slot.time)}
                    >
                      <div className="font-medium">{slot.time}</div>
                      {slot.instructor && <div className="text-xs text-slate-500 mt-1">{slot.instructor}</div>}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Step 3: Contact Information */}
        {step === 3 && (
          <div>
            <div className="flex items-center mb-6">
              <Button variant="ghost" onClick={() => setStep(2)} className="text-emerald-700 hover:text-emerald-800">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Schedule
              </Button>
            </div>

            <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Your Information</h2>

            <div className="max-w-2xl mx-auto">
              <Card className="border-emerald-100">
                <CardHeader>
                  <CardTitle className="text-emerald-700">Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="pb-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Service:</span>
                      <span className="font-medium">{selectedService && services[selectedService].name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Date:</span>
                      <span className="font-medium">
                        {new Date(selectedDate).toLocaleDateString("en-US", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Time:</span>
                      <span className="font-medium">{selectedTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Duration:</span>
                      <span className="font-medium">{selectedService && services[selectedService].duration}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2 mt-2">
                      <span className="text-slate-600">Price:</span>
                      <span className="font-bold text-emerald-700">
                        {selectedService && services[selectedService].price}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <form onSubmit={handleFormSubmit} className="mt-8 space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="studentName">Student Name *</Label>
                    <Input
                      id="studentName"
                      required
                      value={formData.studentName}
                      onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                      className="border-emerald-200 focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <Label htmlFor="parentName">Parent/Guardian Name *</Label>
                    <Input
                      id="parentName"
                      required
                      value={formData.parentName}
                      onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                      className="border-emerald-200 focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="border-emerald-200 focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="border-emerald-200 focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="grade">Current Grade</Label>
                  <Select onValueChange={(value) => setFormData({ ...formData, grade: value })}>
                    <SelectTrigger className="border-emerald-200 focus:border-emerald-500">
                      <SelectValue placeholder="Select grade level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3rd Grade</SelectItem>
                      <SelectItem value="4">4th Grade</SelectItem>
                      <SelectItem value="5">5th Grade</SelectItem>
                      <SelectItem value="6">6th Grade</SelectItem>
                      <SelectItem value="7">7th Grade</SelectItem>
                      <SelectItem value="8">8th Grade</SelectItem>
                      <SelectItem value="9">9th Grade</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="notes">Additional Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Any specific topics you'd like to discuss or questions you have..."
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="border-emerald-200 focus:border-emerald-500"
                  />
                </div>

                <Button type="submit" size="lg" className="w-full bg-emerald-700 hover:bg-emerald-800">
                  Continue to Payment
                </Button>
              </form>
            </div>
          </div>
        )}

        {step === 4 && (
          <div>
            <div className="flex items-center mb-6">
              <Button variant="ghost" onClick={() => setStep(3)} className="text-emerald-700 hover:text-emerald-800">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Details
              </Button>
            </div>

            <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Secure Payment</h2>

            <div className="max-w-2xl mx-auto">
              <Card className="border-emerald-100 mb-6">
                <CardHeader>
                  <CardTitle className="text-emerald-700">Final Booking Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Service:</span>
                      <span className="font-medium">{selectedService && services[selectedService].name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Student:</span>
                      <span className="font-medium">{formData.studentName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Date & Time:</span>
                      <span className="font-medium">
                        {new Date(selectedDate).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}{" "}
                        at {selectedTime}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Duration:</span>
                      <span className="font-medium">{selectedService && services[selectedService].duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Instructor:</span>
                      <span className="font-medium">
                        {timeSlots.find((slot) => slot.time === selectedTime)?.instructor || "TBD"}
                      </span>
                    </div>
                    <div className="border-t pt-3 mt-3">
                      <div className="flex justify-between text-lg">
                        <span className="font-semibold">Total:</span>
                        <span className="font-bold text-emerald-700">
                          {selectedService && services[selectedService].price}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-emerald-100">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <CreditCard className="w-12 h-12 text-emerald-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-slate-900 mb-2">Secure Payment with Stripe</h3>
                    <p className="text-slate-600">
                      Your payment information is encrypted and secure. You'll be redirected to Stripe to complete your
                      payment.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-emerald-50 p-4 rounded-lg">
                      <h4 className="font-medium text-emerald-800 mb-2">What happens next:</h4>
                      <ul className="text-sm text-emerald-700 space-y-1">
                        <li>• Secure payment processing via Stripe</li>
                        <li>• Instant booking confirmation email</li>
                        <li>• Calendar invite with session details</li>
                        <li>• Pre-session reminder 24 hours before</li>
                      </ul>
                    </div>

                    <Button
                      onClick={handlePayment}
                      disabled={isProcessingPayment}
                      size="lg"
                      className="w-full bg-emerald-700 hover:bg-emerald-800"
                    >
                      {isProcessingPayment ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Processing...
                        </>
                      ) : (
                        <>
                          <CreditCard className="w-4 h-4 mr-2" />
                          Pay {selectedService && services[selectedService].price} with Stripe
                        </>
                      )}
                    </Button>

                    <p className="text-xs text-slate-500 text-center">
                      By clicking "Pay with Stripe", you agree to our terms of service and privacy policy. Your payment
                      is secured by 256-bit SSL encryption.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
